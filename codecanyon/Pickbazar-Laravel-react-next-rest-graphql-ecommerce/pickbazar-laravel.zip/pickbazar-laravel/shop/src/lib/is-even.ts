export function isEven(number: number): boolean {
  return number % 2 === 0;
}
