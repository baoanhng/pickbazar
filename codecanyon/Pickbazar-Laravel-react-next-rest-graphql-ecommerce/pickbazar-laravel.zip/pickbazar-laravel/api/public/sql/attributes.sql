INSERT INTO `attributes` (`id`, `slug`, `name`, `shop_id`, `created_at`, `updated_at`) VALUES
(3, 'color', 'Color', 2, '2021-05-09 16:10:31', '2021-05-09 16:10:31'),
(4, 'size', 'Size', 2, '2021-05-09 16:10:40', '2021-05-09 16:10:40'),
(5, 'language', 'Language', 7, '2021-12-18 12:04:40', '2021-12-18 12:04:40'),
(6, 'book-type', 'Book Type', 7, '2021-12-18 12:11:47', '2021-12-18 12:11:47');