INSERT INTO `model_has_permissions` (`permission_id`, `model_type`, `model_id`) VALUES
(2, 'Marvel\\Database\\Models\\User', 1),
(2, 'Marvel\\Database\\Models\\User', 2),
(3, 'Marvel\\Database\\Models\\User', 1);