INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'super_admin', 'api', '2021-06-27 04:13:00', '2021-06-27 04:13:00'),
(2, 'customer', 'api', '2021-06-27 04:13:00', '2021-06-27 04:13:00'),
(3, 'store_owner', 'api', '2021-06-27 04:13:00', '2021-06-27 04:13:00'),
(4, 'staff', 'api', '2021-06-27 04:13:00', '2021-06-27 04:13:00');