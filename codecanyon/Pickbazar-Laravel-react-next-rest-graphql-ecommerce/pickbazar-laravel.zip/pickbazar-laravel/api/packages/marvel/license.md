# The license

Copyright (c) author name <author email>

...Add your license text here...