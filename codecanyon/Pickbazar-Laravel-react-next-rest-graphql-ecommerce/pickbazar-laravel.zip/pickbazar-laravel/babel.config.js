module.exports = {
  babelrcRoots: [".", "packages/*"],
};
